package cts.com.app;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ CalculatorTest.class, UserTest.class, EvenOrOddTest.class

}

)

public class TestSuit1 {

}
