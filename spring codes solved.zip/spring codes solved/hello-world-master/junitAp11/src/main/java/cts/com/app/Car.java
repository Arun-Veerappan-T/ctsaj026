package cts.com.app;

public interface Car {

	boolean needFuel();
	double getEngineTemperature();
	void driveTo(String s);
}
