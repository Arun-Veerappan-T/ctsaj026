package cts.com.app;

public class Calculator {

	public float addition(float a, float b) {
		return a+b;
	}
	
	public float subtraction(float a, float b) {
		return a-b;
	}
	public float multiplication(float a, float b) {
		return a*b;
	}
	
	public float division(float a, float b) {
		return a/b;
	}
	
}
