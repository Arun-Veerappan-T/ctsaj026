package cts.com.app;

public interface StockService {

 double getPrice(Stock stock);
	
}
