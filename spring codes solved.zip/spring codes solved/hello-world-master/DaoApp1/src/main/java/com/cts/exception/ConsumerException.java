package com.cts.exception;

public class ConsumerException extends Exception {

	public ConsumerException(String s) {
	  super(s);
	}
}
