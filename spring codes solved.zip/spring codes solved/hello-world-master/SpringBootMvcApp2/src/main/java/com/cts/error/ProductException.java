package com.cts.error;

public class ProductException  extends Exception{

	public ProductException(String s) {
	  super(s);
	}
}
