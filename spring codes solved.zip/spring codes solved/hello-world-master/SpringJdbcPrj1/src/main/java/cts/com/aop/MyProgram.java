package cts.com.aop;

public class MyProgram {

	public void  display() {
		System.out.println("hello world");
	}
	
}
